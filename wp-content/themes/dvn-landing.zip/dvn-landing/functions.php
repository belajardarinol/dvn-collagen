<?php
function dvn_landing_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'sec_general' , array(
        'title'      => 'General Settings',
        'priority'   => 29,
    ) );

    $wp_customize->add_setting( 'wa_link' , array(
        'default'   => 'https://wa.me/628XXXXXXXXXX?text=Halo, saya ingin order DVN Collagen',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'wa_link', array(
        'label'      => 'WhatsApp Link',
        'section'    => 'sec_general',
        'settings'   => 'wa_link',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'distributor_id' , array(
        'default'   => 'i1684',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'distributor_id', array(
        'label'      => 'Distributor ID',
        'section'    => 'sec_general',
        'settings'   => 'distributor_id',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'dealer_name' , array(
        'default'   => 'DVN X RAYA',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'dealer_name', array(
        'label'      => 'Dealer Name',
        'section'    => 'sec_general',
        'settings'   => 'dealer_name',
        'type'       => 'text',
    ) );
    $wp_customize->add_panel( 'panel_hero' , array(
        'title'      => 'Hero Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_hero' , array(
        'title'      => 'Hero Section Settings',
        'panel'      => 'panel_hero',
    ) );

    $wp_customize->add_setting( 'hero_img_1' , array(
        'default'   => 'https://placehold.co/136x160/fde8ef/c0547a?text=Model+1',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hero_img_1', array(
        'label'      => 'Model 1 Image (Polaroid)',
        'section'    => 'sec_hero',
        'settings'   => 'hero_img_1',
    ) ) );

    $wp_customize->add_setting( 'hero_img_2' , array(
        'default'   => 'https://placehold.co/124x150/f9c6d8/a0336e?text=Model+2',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hero_img_2', array(
        'label'      => 'Model 2 Image (Polaroid)',
        'section'    => 'sec_hero',
        'settings'   => 'hero_img_2',
    ) ) );

    $wp_customize->add_setting( 'hero_headline' , array(
        'default'   => 'Kulit Tampak <span>Lebih Muda</span> Dimulai dari Dalam',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'hero_headline', array(
        'label'      => 'Headline',
        'section'    => 'sec_hero',
        'settings'   => 'hero_headline',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'hero_sub' , array(
        'default'   => 'Ribuan wanita Indonesia sudah merasakan perubahan nyata. Sekarang giliran Anda.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'hero_sub', array(
        'label'      => 'Subheadline',
        'section'    => 'sec_hero',
        'settings'   => 'hero_sub',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'hero_cta' , array(
        'default'   => '✦ Beli Sekarang – Chat via WhatsApp',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'hero_cta', array(
        'label'      => 'CTA Button',
        'section'    => 'sec_hero',
        'settings'   => 'hero_cta',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'hero_cta_micro' , array(
        'default'   => 'Produk Original • Tersegel • Pengiriman ke Seluruh Indonesia',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'hero_cta_micro', array(
        'label'      => 'CTA Micro',
        'section'    => 'sec_hero',
        'settings'   => 'hero_cta_micro',
        'type'       => 'text',
    ) );
    $wp_customize->add_panel( 'panel_problem' , array(
        'title'      => 'Problem Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_problem' , array(
        'title'      => 'Problem Section Settings',
        'panel'      => 'panel_problem',
    ) );

    $wp_customize->add_setting( 'prob_tag' , array(
        'default'   => 'Masalah yang Anda Rasakan',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_problem',
        'settings'   => 'prob_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'prob_title' , array(
        'default'   => 'Pernah Merasa <span>Tua Sebelum Waktunya?</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_title', array(
        'label'      => 'Title',
        'section'    => 'sec_problem',
        'settings'   => 'prob_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'prob_body' , array(
        'default'   => 'Bercermin dan melihat kulit yang tidak lagi sesegar dulu — itu menyakitkan. Tapi Anda tidak sendirian.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_body', array(
        'label'      => 'Body',
        'section'    => 'sec_problem',
        'settings'   => 'prob_body',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'prob_1_t' , array(
        'default'   => 'Kerutan & Garis Halus',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_1_t', array(
        'label'      => 'Prob 1 Title',
        'section'    => 'sec_problem',
        'settings'   => 'prob_1_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'prob_1_d' , array(
        'default'   => 'Muncul lebih awal dari yang seharusnya, membuat wajah terlihat lelah setiap hari.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_1_d', array(
        'label'      => 'Prob 1 Desc',
        'section'    => 'sec_problem',
        'settings'   => 'prob_1_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'prob_2_t' , array(
        'default'   => 'Flek Hitam Membandel',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_2_t', array(
        'label'      => 'Prob 2 Title',
        'section'    => 'sec_problem',
        'settings'   => 'prob_2_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'prob_2_d' , array(
        'default'   => 'Bekas jerawat dan paparan sinar matahari meninggalkan noda yang susah hilang.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_2_d', array(
        'label'      => 'Prob 2 Desc',
        'section'    => 'sec_problem',
        'settings'   => 'prob_2_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'prob_3_t' , array(
        'default'   => 'Kulit Kendur & Kusam',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_3_t', array(
        'label'      => 'Prob 3 Title',
        'section'    => 'sec_problem',
        'settings'   => 'prob_3_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'prob_3_d' , array(
        'default'   => 'Elastisitas kulit menurun seiring usia, membuat wajah tampak tidak segar.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_3_d', array(
        'label'      => 'Prob 3 Desc',
        'section'    => 'sec_problem',
        'settings'   => 'prob_3_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'prob_4_t' , array(
        'default'   => 'Penuaan Dini di Wajah',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_4_t', array(
        'label'      => 'Prob 4 Title',
        'section'    => 'sec_problem',
        'settings'   => 'prob_4_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'prob_4_d' , array(
        'default'   => 'Polusi, stres, dan gaya hidup modern mempercepat proses penuaan kulit Anda.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'prob_4_d', array(
        'label'      => 'Prob 4 Desc',
        'section'    => 'sec_problem',
        'settings'   => 'prob_4_d',
        'type'       => 'textarea',
    ) );
    $wp_customize->add_panel( 'panel_agitate' , array(
        'title'      => 'Agitate Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_agitate' , array(
        'title'      => 'Agitate Section Settings',
        'panel'      => 'panel_agitate',
    ) );

    $wp_customize->add_setting( 'agit_tag' , array(
        'default'   => 'Tahukah Anda?',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'agit_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_agitate',
        'settings'   => 'agit_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'agit_title' , array(
        'default'   => 'Setiap Hari Kulit Anda <span>Mengirim Sinyal Bahaya</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'agit_title', array(
        'label'      => 'Title',
        'section'    => 'sec_agitate',
        'settings'   => 'agit_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'agit_quote' , array(
        'default'   => 'Paparan sinar UV, polusi udara, dan tekanan gaya hidup adalah musuh utama kesehatan kulit. Tanpa perlindungan dari dalam, kerusakan terus berlanjut diam-diam.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'agit_quote', array(
        'label'      => 'Quote',
        'section'    => 'sec_agitate',
        'settings'   => 'agit_quote',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'agit_body' , array(
        'default'   => 'Produk luar saja tidak cukup. Kulit butuh nutrisi dari dalam agar regenerasi sel berjalan optimal. Itulah mengapa solusi topikal sering terasa sia-sia.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'agit_body', array(
        'label'      => 'Body',
        'section'    => 'sec_agitate',
        'settings'   => 'agit_body',
        'type'       => 'textarea',
    ) );
    $wp_customize->add_panel( 'panel_solution' , array(
        'title'      => 'Solution Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_solution' , array(
        'title'      => 'Solution Section Settings',
        'panel'      => 'panel_solution',
    ) );

    $wp_customize->add_setting( 'sol_tag' , array(
        'default'   => 'Solusi Terbukti',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_solution',
        'settings'   => 'sol_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'sol_title' , array(
        'default'   => 'Rawat Kulit Anda <span>dari Dalam ke Luar</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_title', array(
        'label'      => 'Title',
        'section'    => 'sec_solution',
        'settings'   => 'sol_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'sol_body' , array(
        'default'   => 'DVN dengan Collagen hadir sebagai suplemen pendamping perawatan kulit harian Anda — formulasi internasional yang telah meraih penghargaan Superbrands Worldwide 2024.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_body', array(
        'label'      => 'Body',
        'section'    => 'sec_solution',
        'settings'   => 'sol_body',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'sol_1_t' , array(
        'default'   => 'Membantu Menjaga Kesehatan Kulit dari Dalam',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_1_t', array(
        'label'      => 'Sol 1 Title',
        'section'    => 'sec_solution',
        'settings'   => 'sol_1_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'sol_1_d' , array(
        'default'   => 'Kolagen terhidrolisat mendukung nutrisi kulit secara menyeluruh sebagai bagian dari rutinitas harian.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_1_d', array(
        'label'      => 'Sol 1 Desc',
        'section'    => 'sec_solution',
        'settings'   => 'sol_1_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'sol_2_t' , array(
        'default'   => 'Mendukung Penampilan Tetap Segar Sepanjang Hari',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_2_t', array(
        'label'      => 'Sol 2 Title',
        'section'    => 'sec_solution',
        'settings'   => 'sol_2_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'sol_2_d' , array(
        'default'   => 'Kombinasi Natrium Hyaluronat & Vitamin C membantu menjaga kulit terasa lembap dan bercahaya.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_2_d', array(
        'label'      => 'Sol 2 Desc',
        'section'    => 'sec_solution',
        'settings'   => 'sol_2_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'sol_3_t' , array(
        'default'   => 'Melengkapi Gaya Hidup Sehat Modern',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_3_t', array(
        'label'      => 'Sol 3 Title',
        'section'    => 'sec_solution',
        'settings'   => 'sol_3_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'sol_3_d' , array(
        'default'   => 'Tablet kunyah yang praktis, mudah dikonsumsi kapan saja — cocok untuk ibu aktif dan profesional sibuk.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_3_d', array(
        'label'      => 'Sol 3 Desc',
        'section'    => 'sec_solution',
        'settings'   => 'sol_3_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'sol_4_t' , array(
        'default'   => 'Formulasi Bahan Berkualitas Internasional',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_4_t', array(
        'label'      => 'Sol 4 Title',
        'section'    => 'sec_solution',
        'settings'   => 'sol_4_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'sol_4_d' , array(
        'default'   => 'Resveratrol dari Jepang, Delima dari Korea, dan Natrium Hyaluronat dari Prancis — dipadukan dalam satu tablet.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_4_d', array(
        'label'      => 'Sol 4 Desc',
        'section'    => 'sec_solution',
        'settings'   => 'sol_4_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'sol_cta' , array(
        'default'   => '✦ Dapatkan DVN Collagen Sekarang',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_cta', array(
        'label'      => 'CTA Button',
        'section'    => 'sec_solution',
        'settings'   => 'sol_cta',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'sol_cta_micro' , array(
        'default'   => 'BPOM RI • Halal MUI • Produksi Standar Internasional',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'sol_cta_micro', array(
        'label'      => 'CTA Micro',
        'section'    => 'sec_solution',
        'settings'   => 'sol_cta_micro',
        'type'       => 'text',
    ) );
    $wp_customize->add_panel( 'panel_ingredients' , array(
        'title'      => 'Ingredients Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_ingredients' , array(
        'title'      => 'Ingredients Section Settings',
        'panel'      => 'panel_ingredients',
    ) );

    $wp_customize->add_setting( 'ing_tag' , array(
        'default'   => 'Formulasi Premium',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'ing_title' , array(
        'default'   => 'Dipadukan dengan Bahan <span>Internasional Pilihan</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_title', array(
        'label'      => 'Title',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'ing_body' , array(
        'default'   => 'Setiap komponen dalam DVN dipilih secara selektif untuk melengkapi gaya hidup sehat modern Anda.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_body', array(
        'label'      => 'Body',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_body',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'ing_1_t' , array(
        'default'   => '🍇 Resveratrol (Jepang)',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_1_t', array(
        'label'      => 'Ing 1 Title',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_1_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'ing_1_d' , array(
        'default'   => 'Senyawa alami dari anggur & beri yang dipilih sebagai bahan nutrisi tambahan dalam formulasi DVN.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_1_d', array(
        'label'      => 'Ing 1 Desc',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_1_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'ing_2_t' , array(
        'default'   => '🍎 Delima (Korea)',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_2_t', array(
        'label'      => 'Ing 2 Title',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_2_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'ing_2_d' , array(
        'default'   => 'Buah kaya nutrisi yang digunakan sebagai bahan pendukung kesehatan kulit dalam DVN Collagen.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_2_d', array(
        'label'      => 'Ing 2 Desc',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_2_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'ing_3_t' , array(
        'default'   => '💧 Natrium Hyaluronat (Prancis)',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_3_t', array(
        'label'      => 'Ing 3 Title',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_3_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'ing_3_d' , array(
        'default'   => 'Komponen penting yang membantu menjaga kelembapan kulit sebagai bagian dari rutinitas harian.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_3_d', array(
        'label'      => 'Ing 3 Desc',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_3_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'ing_4_t' , array(
        'default'   => '✨ Kolagen Terhidrolisat',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_4_t', array(
        'label'      => 'Ing 4 Title',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_4_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'ing_4_d' , array(
        'default'   => 'Protein penting sebagai nutrisi tambahan untuk mendukung kesehatan kulit dari dalam.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'ing_4_d', array(
        'label'      => 'Ing 4 Desc',
        'section'    => 'sec_ingredients',
        'settings'   => 'ing_4_d',
        'type'       => 'textarea',
    ) );
    $wp_customize->add_panel( 'panel_timeline' , array(
        'title'      => 'Timeline Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_timeline' , array(
        'title'      => 'Timeline Section Settings',
        'panel'      => 'panel_timeline',
    ) );

    $wp_customize->add_setting( 'tl_tag' , array(
        'default'   => 'Perjalanan Kulit Anda',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'tl_title' , array(
        'default'   => 'Apa yang Terjadi Setelah <span>Konsumsi Rutin?</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_title', array(
        'label'      => 'Title',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'tl_body' , array(
        'default'   => 'Hasil terbaik didapat dengan konsumsi sesuai anjuran dan konsisten setiap hari.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_body', array(
        'label'      => 'Body',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_body',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'tl_1_t' , array(
        'default'   => 'Minggu 1 – Mulai Meresap',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_1_t', array(
        'label'      => 'TL 1 Title',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_1_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'tl_1_d' , array(
        'default'   => 'Nutrisi mulai diserap tubuh. Kulit terasa lebih nyaman dan lembap sepanjang hari.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_1_d', array(
        'label'      => 'TL 1 Desc',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_1_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'tl_2_t' , array(
        'default'   => 'Minggu 2–3 – Awal Perubahan',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_2_t', array(
        'label'      => 'TL 2 Title',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_2_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'tl_2_d' , array(
        'default'   => 'Rutinitas terbentuk. Penampilan kulit mulai tampak lebih segar dan bercahaya.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_2_d', array(
        'label'      => 'TL 2 Desc',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_2_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'tl_3_t' , array(
        'default'   => 'Bulan 1 – Perubahan Terasa',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_3_t', array(
        'label'      => 'TL 3 Title',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_3_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'tl_3_d' , array(
        'default'   => 'Kulit tampak lebih sehat. Elastisitas membaik, wajah terlihat lebih segar dari sebelumnya.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_3_d', array(
        'label'      => 'TL 3 Desc',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_3_d',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'tl_4_t' , array(
        'default'   => 'Bulan 3+ – Manfaat Optimal',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_4_t', array(
        'label'      => 'TL 4 Title',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_4_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'tl_4_d' , array(
        'default'   => 'Dengan konsumsi rutin, manfaat nutrisi dari dalam terasakan lebih optimal dan konsisten.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'tl_4_d', array(
        'label'      => 'TL 4 Desc',
        'section'    => 'sec_timeline',
        'settings'   => 'tl_4_d',
        'type'       => 'textarea',
    ) );
    $wp_customize->add_panel( 'panel_proof' , array(
        'title'      => 'Social Proof Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_proof' , array(
        'title'      => 'Social Proof Section Settings',
        'panel'      => 'panel_proof',
    ) );

    $wp_customize->add_setting( 'proof_tag' , array(
        'default'   => 'Dipercaya Ribuan Orang',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'proof_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_proof',
        'settings'   => 'proof_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'proof_title' , array(
        'default'   => 'Bergabung Bersama <span>Komunitas DVN</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'proof_title', array(
        'label'      => 'Title',
        'section'    => 'sec_proof',
        'settings'   => 'proof_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'proof_1_t' , array(
        'default'   => '50.000+',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'proof_1_t', array(
        'label'      => 'Proof 1 Big',
        'section'    => 'sec_proof',
        'settings'   => 'proof_1_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'proof_1_d' , array(
        'default'   => 'Pengguna Aktif di Indonesia',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'proof_1_d', array(
        'label'      => 'Proof 1 Label',
        'section'    => 'sec_proof',
        'settings'   => 'proof_1_d',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'proof_2_t' , array(
        'default'   => '⭐ 4.8/5',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'proof_2_t', array(
        'label'      => 'Proof 2 Big',
        'section'    => 'sec_proof',
        'settings'   => 'proof_2_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'proof_2_d' , array(
        'default'   => 'Rating dari Ribuan Ulasan Pelanggan',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'proof_2_d', array(
        'label'      => 'Proof 2 Label',
        'section'    => 'sec_proof',
        'settings'   => 'proof_2_d',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'proof_3_t' , array(
        'default'   => 'Superbrands',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'proof_3_t', array(
        'label'      => 'Proof 3 Big',
        'section'    => 'sec_proof',
        'settings'   => 'proof_3_t',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'proof_3_d' , array(
        'default'   => 'Penghargaan Superbrands Worldwide 2024',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'proof_3_d', array(
        'label'      => 'Proof 3 Label',
        'section'    => 'sec_proof',
        'settings'   => 'proof_3_d',
        'type'       => 'text',
    ) );
    $wp_customize->add_panel( 'panel_comparison' , array(
        'title'      => 'Comparison Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_comparison' , array(
        'title'      => 'Comparison Section Settings',
        'panel'      => 'panel_comparison',
    ) );

    $wp_customize->add_setting( 'comp_tag' , array(
        'default'   => 'Perbandingan',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'comp_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_comparison',
        'settings'   => 'comp_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'comp_title' , array(
        'default'   => 'DVN vs Produk <span>Lainnya</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'comp_title', array(
        'label'      => 'Title',
        'section'    => 'sec_comparison',
        'settings'   => 'comp_title',
        'type'       => 'textarea',
    ) );
    $wp_customize->add_panel( 'panel_pricing' , array(
        'title'      => 'Pricing Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_pricing' , array(
        'title'      => 'Pricing Section Settings',
        'panel'      => 'panel_pricing',
    ) );

    $wp_customize->add_setting( 'price_tag' , array(
        'default'   => 'Investasi Kecantikan Anda',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_pricing',
        'settings'   => 'price_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'price_title' , array(
        'default'   => 'Lebih Hemat dari <span>Perawatan Salon</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_title', array(
        'label'      => 'Title',
        'section'    => 'sec_pricing',
        'settings'   => 'price_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'price_body' , array(
        'default'   => 'Perawatan salon bisa menghabiskan ratusan ribu setiap kunjungan. DVN Collagen memberikan nutrisi dari dalam setiap hari — lebih efisien, lebih konsisten.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_body', array(
        'label'      => 'Body',
        'section'    => 'sec_pricing',
        'settings'   => 'price_body',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'price_pop' , array(
        'default'   => '✦ TERPOPULER',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_pop', array(
        'label'      => 'Popular Tag',
        'section'    => 'sec_pricing',
        'settings'   => 'price_pop',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'price_name' , array(
        'default'   => 'DVN Collagen – Paket Resmi',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_name', array(
        'label'      => 'Package Name',
        'section'    => 'sec_pricing',
        'settings'   => 'price_name',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'price_text' , array(
        'default'   => 'Chat WA',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_text', array(
        'label'      => 'Price Text',
        'section'    => 'sec_pricing',
        'settings'   => 'price_text',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'price_sub' , array(
        'default'   => 'Hubungi kami untuk harga terbaik hari ini',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_sub', array(
        'label'      => 'Price Sub',
        'section'    => 'sec_pricing',
        'settings'   => 'price_sub',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'price_cta' , array(
        'default'   => '✦ Hubungi Dealer Resmi',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_cta', array(
        'label'      => 'CTA Button',
        'section'    => 'sec_pricing',
        'settings'   => 'price_cta',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'price_cta_micro' , array(
        'default'   => 'Ratusan pelanggan puas setiap bulannya',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'price_cta_micro', array(
        'label'      => 'CTA Micro',
        'section'    => 'sec_pricing',
        'settings'   => 'price_cta_micro',
        'type'       => 'text',
    ) );
    $wp_customize->add_panel( 'panel_guarantee' , array(
        'title'      => 'Guarantee Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_guarantee' , array(
        'title'      => 'Guarantee Section Settings',
        'panel'      => 'panel_guarantee',
    ) );

    $wp_customize->add_setting( 'guar_tag' , array(
        'default'   => 'Ketenangan Pikiran Anda',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'guar_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_guarantee',
        'settings'   => 'guar_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'guar_title' , array(
        'default'   => 'Beli dengan <span>Rasa Aman</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'guar_title', array(
        'label'      => 'Title',
        'section'    => 'sec_guarantee',
        'settings'   => 'guar_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'guar_box_title' , array(
        'default'   => 'Jaminan Produk Original',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'guar_box_title', array(
        'label'      => 'Box Title',
        'section'    => 'sec_guarantee',
        'settings'   => 'guar_box_title',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'guar_box_body' , array(
        'default'   => 'Setiap pembelian melalui dealer resmi ID <strong>{DI}</strong> dijamin keaslian dan kualitasnya. Kemasan tersegel, produk teregistrasi BPOM, dan bersertifikat Halal MUI — ketenangan pikiran Anda adalah prioritas kami.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'guar_box_body', array(
        'label'      => 'Box Body (Use {DI} for ID)',
        'section'    => 'sec_guarantee',
        'settings'   => 'guar_box_body',
        'type'       => 'textarea',
    ) );
    $wp_customize->add_panel( 'panel_scarcity' , array(
        'title'      => 'Scarcity Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_scarcity' , array(
        'title'      => 'Scarcity Section Settings',
        'panel'      => 'panel_scarcity',
    ) );

    $wp_customize->add_setting( 'scar_tag' , array(
        'default'   => '⏰ Penawaran Terbatas',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'scar_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_scarcity',
        'settings'   => 'scar_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'scar_title' , array(
        'default'   => 'Stok Terbatas untuk <span style=\"color:#ffc2d4;\">Periode Ini</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'scar_title', array(
        'label'      => 'Title',
        'section'    => 'sec_scarcity',
        'settings'   => 'scar_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'scar_body' , array(
        'default'   => 'Harga spesial berakhir dalam:',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'scar_body', array(
        'label'      => 'Body',
        'section'    => 'sec_scarcity',
        'settings'   => 'scar_body',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'scar_sub' , array(
        'default'   => 'Jangan sampai kehabisan — stok terbatas tiap periode.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'scar_sub', array(
        'label'      => 'Subtext',
        'section'    => 'sec_scarcity',
        'settings'   => 'scar_sub',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'scar_cta' , array(
        'default'   => '✦ Amankan Stok Saya Sekarang',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'scar_cta', array(
        'label'      => 'CTA Button',
        'section'    => 'sec_scarcity',
        'settings'   => 'scar_cta',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'scar_cta_micro' , array(
        'default'   => 'Respon cepat dalam hitungan menit',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'scar_cta_micro', array(
        'label'      => 'CTA Micro',
        'section'    => 'sec_scarcity',
        'settings'   => 'scar_cta_micro',
        'type'       => 'text',
    ) );
    $wp_customize->add_panel( 'panel_faq' , array(
        'title'      => 'FAQ Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_faq' , array(
        'title'      => 'FAQ Section Settings',
        'panel'      => 'panel_faq',
    ) );

    $wp_customize->add_setting( 'faq_tag' , array(
        'default'   => 'Pertanyaan Umum',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'faq_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_faq',
        'settings'   => 'faq_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'faq_title' , array(
        'default'   => 'Ada yang <span>Ingin Ditanyakan?</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'faq_title', array(
        'label'      => 'Title',
        'section'    => 'sec_faq',
        'settings'   => 'faq_title',
        'type'       => 'textarea',
    ) );
    $wp_customize->add_panel( 'panel_team' , array(
        'title'      => 'Dealer / Team Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_team' , array(
        'title'      => 'Dealer / Team Section Settings',
        'panel'      => 'panel_team',
    ) );

    $wp_customize->add_setting( 'team_tag' , array(
        'default'   => 'Dealer Resmi Anda',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'team_tag', array(
        'label'      => 'Tag',
        'section'    => 'sec_team',
        'settings'   => 'team_tag',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'team_title' , array(
        'default'   => 'Dapatkan DVN dari <span>Sumber Terpercaya</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'team_title', array(
        'label'      => 'Title',
        'section'    => 'sec_team',
        'settings'   => 'team_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'team_desc' , array(
        'default'   => 'Dapatkan DVN original & resmi dengan kualitas terjaga dan kemasan tersegel aman. Dengan konsumsi rutin sesuai anjuran, DVN membantu menjaga elastisitas dan tampilan kulit tetap sehat.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'team_desc', array(
        'label'      => 'Desc',
        'section'    => 'sec_team',
        'settings'   => 'team_desc',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'team_cta' , array(
        'default'   => '✦ Chat dengan Dealer Resmi',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'team_cta', array(
        'label'      => 'CTA Button',
        'section'    => 'sec_team',
        'settings'   => 'team_cta',
        'type'       => 'text',
    ) );

    $wp_customize->add_setting( 'team_cta_micro' , array(
        'default'   => 'Respons dalam hitungan menit • Mon-Sun 08.00-22.00',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'team_cta_micro', array(
        'label'      => 'CTA Micro',
        'section'    => 'sec_team',
        'settings'   => 'team_cta_micro',
        'type'       => 'text',
    ) );
    $wp_customize->add_panel( 'panel_final_cta' , array(
        'title'      => 'Final CTA Section',
        'priority'   => 30,
    ) );
    $wp_customize->add_section( 'sec_final_cta' , array(
        'title'      => 'Final CTA Section Settings',
        'panel'      => 'panel_final_cta',
    ) );

    $wp_customize->add_setting( 'final_title' , array(
        'default'   => 'Mulai Perjalanan <span>Kulit Cantikmu Hari Ini</span>',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'final_title', array(
        'label'      => 'Title',
        'section'    => 'sec_final_cta',
        'settings'   => 'final_title',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'final_body' , array(
        'default'   => 'Ribuan wanita Indonesia sudah memulai. Jangan tunda lagi — setiap hari tanpa nutrisi adalah hari yang terlewat.',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'final_body', array(
        'label'      => 'Body',
        'section'    => 'sec_final_cta',
        'settings'   => 'final_body',
        'type'       => 'textarea',
    ) );

    $wp_customize->add_setting( 'final_cta' , array(
        'default'   => '✦ Beli Sekarang via WhatsApp',
        'transport' => 'refresh',
    ) );
    $wp_customize->add_control( 'final_cta', array(
        'label'      => 'CTA Button',
        'section'    => 'sec_final_cta',
        'settings'   => 'final_cta',
        'type'       => 'text',
    ) );
}
add_action( 'customize_register', 'dvn_landing_customize_register' );
